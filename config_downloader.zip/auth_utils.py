import os
import sys
# 因为是要给simple_ui用的，所以要把这个库写薄一点，不要import太多东西，避免回头打出来包太大，加载的慢

jj=os.path.join

# 目录、文件位置定义， 准备好目录
if hasattr(sys, "frozen"):
    appPathDir = os.path.dirname(sys.executable)
else:
    appPathDir = os.path.dirname(os.path._getfullpathname(__file__))
appPathDir = os.path.dirname(appPathDir)  # 把py文件都放到bin目录里，根目录就

conf_dir = jj(appPathDir, 'conf')  # 配置文件根目录

password_conf_file = jj(conf_dir, "user.txt")  # 公司里的用户名、密码，要加密吗？ 有界面后再说吧
password_conf_file_domain = jj(conf_dir, 'user_domain.txt')


def get_w3_account():
    return get_account(password_conf_file)


def get_domain_account():
    return get_account(password_conf_file_domain)


def set_w3_account(uid, psw):
    set_account(password_conf_file, uid, psw)


def set_domain_account(uid, psw):
    set_account(password_conf_file_domain, uid, psw)


def get_account(file_name=password_conf_file):
    # 获取预置的用户名、密码, 这个账户密码主要是w3密码，但是目前用公司的AD服务来鉴权，用的是域账户密码
    if not os.path.isfile(file_name):
        msg = "[错误][方法]:" + "get_account" + " |用户名配置文件不存在：" + file_name
        # logger.info(msg)
        return False, msg, "", ""

    with open(file_name, 'r', encoding='utf8') as f:
        lines = f.readlines()
        account = ''
        password = ''
        if len(lines) > 1:
            account = lines[0].strip().split("=")[1]
            password = lines[1].strip().split("=")[1]

        return True, 'ok', account, password


def set_account(file_name, userid, password):
    con = "id=" + userid + "\n" + "password="+ password
    with open(file_name, 'w', encoding='utf8') as f:
        f.write(con)
