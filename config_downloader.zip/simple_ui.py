#coding:utf8
import tkinter as tk
from tkinter import messagebox
import tkinter.font as tkFont
import re
import click

import ui_login
import ui_select_mode


class input_window:
    # 包含一个输入控件的窗体，在utils.py里面不太好搞，所以用一个独立的进程。
    # 然后用subprocess来拉起，然后通过stdout来传递用户的简答输入信息。
    # 这个功能、结构特别简单，变量名就用默认生成的就可以了
    def __init__(self, root):
        #setting title
        root.title("ok")
        #setting window size
        self.root = root
        width=583
        height=198
        screenwidth = root.winfo_screenwidth()
        screenheight = root.winfo_screenheight()
        alignstr = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
        root.geometry(alignstr)
        root.resizable(width=False, height=False)

        GLabel_430=tk.Label(root)
        ft = tkFont.Font(family='宋体',size=10)
        GLabel_430["font"] = ft
        GLabel_430["fg"] = "#333333"
        GLabel_430["justify"] = "center"
        GLabel_430["text"] = "请输入需要访问的url:(例如:www.zhihu.com)"
        GLabel_430.place(x=30,y=20,width=189,height=30)

        self.GLineEdit_928=tk.Entry(root)
        self.GLineEdit_928["borderwidth"] = "1px"
        ft = tkFont.Font(family='宋体',size=10)
        self.GLineEdit_928["font"] = ft
        self.GLineEdit_928["fg"] = "#333333"
        self.GLineEdit_928["justify"] = "center"
        self.GLineEdit_928["text"] = "Entry"
        self.GLineEdit_928.place(x=60,y=60,width=473,height=34)
        self.GLineEdit_928.focus()

        GButton_357=tk.Button(root)
        GButton_357["bg"] = "#efefef"
        ft = tkFont.Font(family='宋体',size=10)
        GButton_357["font"] = ft
        GButton_357["fg"] = "#000000"
        GButton_357["justify"] = "center"
        GButton_357["text"] = "OK"
        GButton_357.place(x=370,y=120,width=155,height=30)
        GButton_357["command"] = self.GButton_357_command

    def GButton_357_command(self):
        value = self.GLineEdit_928.get().strip()
        if "http" not in value:
            value = "https://" + value

        ptn =  ("((http|https)://)(www.)?" +
             "[a-zA-Z0-9@:%._\\+~#?&//=]" +
             "{2,256}\\.[a-z]" +
             "{2,6}\\b([-a-zA-Z0-9@:%" +
             "._\\+~#?&//=]*)")

        if re.match(ptn, value):
            print(value)
            self.root.destroy()
        else:
            messagebox.showinfo(title="注意", message="文本框内容为空或输入有误，请输入要登录的url。")


class Info_box_1:
    # 用于提示登录完成，cookie字符串被复制到粘贴板的提示信息   
    def __init__(self, root):
        #setting title
        self.root = root
        root.title("注意")
        #setting window size
        width=355
        height=124
        screenwidth = root.winfo_screenwidth()
        screenheight = root.winfo_screenheight()
        alignstr = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2 -400, (screenheight - height) / 2-400)
        root.geometry(alignstr)
        root.resizable(width=False, height=False)

        GLabel_125=tk.Label(root)
        ft = tkFont.Font(family='宋体',size=9)
        GLabel_125["font"] = ft
        GLabel_125["fg"] = "#333333"
        GLabel_125["justify"] = "left"
        GLabel_125["text"] = "完成登录，页面跳转完成后，请单击下方的”完成“按钮。"
        GLabel_125.place(x=10,y=0,width=330,height=48)

        GButton_183=tk.Button(root)
        GButton_183["bg"] = "#efefef"
        ft = tkFont.Font(family='宋体',size=10)
        GButton_183["font"] = ft
        GButton_183["fg"] = "#000000"
        GButton_183["justify"] = "center"
        GButton_183["text"] = "完成"
        GButton_183.place(x=220,y=80,width=118,height=30)
        GButton_183["command"] = self.GButton_183_command
        GButton_183.focus()

        GLabel_275=tk.Label(root)
        ft = tkFont.Font(family='宋体',size=9)
        GLabel_275["font"] = ft
        GLabel_275["fg"] = "#cc0000"
        GLabel_275["justify"] = "left"
        GLabel_275["text"] = "本站点的cookie信息将被复制到您系统的粘贴板。"
        GLabel_275.place(x=10,y=30,width=330,height=30)

    def GButton_183_command(self):
        print("ok")        
        self.root.destroy()    


def start_input_box():
    root = tk.Tk()
    app = input_window(root)
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.mainloop()


def start_info_box_1():
    root = tk.Tk()
    app = Info_box_1(root)
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.mainloop()


@click.command()
@click.option('--act', help="action type")
def create_ui(act):
    if act == "input":
        start_input_box()
    elif act == "info1":
        start_info_box_1()
    elif act == "login":
        ui_login.vp_start_gui()
    elif act == 'selectmode':
        ui_select_mode.vp_start_gui()


if __name__ == "__main__":
    # print(os.path.basename(__file__))
    create_ui()
