# 主要负责定期扫描download目录中的所有目录，根据download目录中子目录的中的json文件中的id（url），去爬虫中心去查这个url所有相关的文件的md5值，然后分别调用王嘎那边的接口，去和谛听做对接，创建知识。
# 因为这个功能相对独立，我就把它从crawler_process.py里面抽取出来。
# 但打包的时候不用把它单独打一个exe，把它当module导入crawler_process，然后在那个里面用multiprocess拉起来就可以了。
# 它和utils等是打包在一起的
import os
import time
from utils import download_root_dir, retSubFolderList, retSubFolderPathList
from concurrent.futures import ThreadPoolExecutor, wait, ALL_COMPLETED

jj=os.path.join
executor = ThreadPoolExecutor(max_workers=2)

def process_folder(folder_path):
    # 处理单个目录中已经爬取下来的数据、和中心的数据对比，要么放弃； 要么提交、更改中心的数据
    pass

def start():
    # 主循环
    while 1:
        src_folders = retSubFolderPathList(download_root_dir)
        if src_folders:
            task = [executor.submit(process_folder, folder_path) for folder_path in src_folders]
            wait(task, return_when=ALL_COMPLETED)
        time.sleep(2)  

if __name__=="__main__":
    start()