import os
import re
import sys
import json
import socket
import base64
import time
from datetime import datetime
from urllib.parse import urlparse
from urllib.parse import urljoin
import urllib.request
from urllib import request
import tempfile
import inspect
import glob
import logging
from logging.handlers import RotatingFileHandler
import copy
from concurrent.futures import ThreadPoolExecutor, wait, ALL_COMPLETED
import random
import subprocess
import shlex
import zipfile
import shutil
from selenium.common.exceptions import TimeoutException

import win32clipboard
import win32com.client
from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import PIL.Image
import zhconv
import win32api
from jsonpath_rw import jsonpath, parse  # 用于unfold json类型的页面

# 这个工具库主要都和网络、webdriver等配置相关，所以建议的的使用方法：import utils , 然后r,msg = utils.init(),如果r为真，才能继续。

# 把方法写到库模块的目的是为了在C/S两侧都能重用这个模块，作为库模块没办法用全局变量
# 用个模块，把变量设置到这个模块里
# 初始化顺序是：import这个模块的时候，先默认初始化，然后加载配置文件中存在的配置项
import shared_obj

jj = os.path.join

from pyquery import PyQuery as pq
def pq_fix(con, **kwargs):
    # 当页面中万一有\x00字符的时候，就会导致pyquery查询失败，这个bug查了好久
    if type(con) == str:
        return pq(con.replace("\x00", ""), **kwargs)
    else:
        return pq(con, **kwargs)

# 目录、文件位置定义， 准备好目录
if hasattr(sys, "frozen"):
    appPathDir = os.path.dirname(sys.executable)
else:
    appPathDir = os.path.dirname(os.path._getfullpathname(__file__))

appPathDir = os.path.dirname(appPathDir)  # 把py文件都放到bin目录里，根目录就变成上一层

bin_dir = jj(appPathDir, 'bin')  # 二进制目录，后续py文件都会被编译成二进制
simple_ui_bin_path = jj(bin_dir, "simple_ui.exe")

log_dir = jj(appPathDir, "log")  # 日志
download_root_dir = jj(appPathDir, 'download')  # 下载根目录
tmp_root_dir = jj(appPathDir, 'tmp')  # 下载的临时根目录
conf_dir = jj(appPathDir, 'conf')  # 配置文件根目录
cache_dir = jj(appPathDir, 'cache')  # 缓存目录，用于临时缓存一些数据的，比如bottom_unfold的结果
site_defines_dir = jj(conf_dir, "site_defines")  # 站点定义文件的根目录

third_dir = jj(appPathDir, '3rd')  # 第三方的目录
others_dir = jj(third_dir, 'others')  # others目录

certmgr_bin_path = jj(others_dir, 'certmgr.exe')

chromedriver_dir = jj(third_dir, 'chromedriver')  # chromedriver的目录
chromedriver_bin_path = jj(chromedriver_dir, "chromedriver.exe")

# 放unfold的缓存数据，格式json，文件名是unfold_define中的define_id
cache_unfolder_dir = jj(cache_dir, "unfolder")

# 1. 本目录用于同步系统中已经存在的站点定义。
# 2. 如果您对某个站点有自定义个需求，可以在custom目录中创建相同regex的配置，custom中regex相同的配置优先级会更高。
# 3. 如果你希望能共享某个配置，使之持久化到common中（这样其他人就可以获取到），可以在前端系统页面中中选择自定义的点击提交，待管理员审核后通过后，会被同步到common中。
site_common_dir = jj(site_defines_dir, "common")  # 站点定义common文件的根目录
site_custom_dir = jj(site_defines_dir, "custom")  # 站点定义custom文件的根目录

sys_conf_file = jj(conf_dir, 'utils_conf.json')  # 工具配置文件
password_conf_file = jj(conf_dir, "user.txt")  # 公司里的用户名、密码，要加密吗？ 有界面后再说吧
unfolder_map_define = "unfolder_map.json"
downloader_map_define = "downloader_map.json"

# 不同展开器的全量定义都在unfolder中， 在展开器定义中要增加一个type字段
common_unfolder_map_path = jj(site_common_dir, unfolder_map_define)
common_downloader_map_path = jj(site_common_dir, downloader_map_define)

custom_unfolder_map_path = jj(site_custom_dir, unfolder_map_define)
custom_downloader_map_path = jj(site_custom_dir, downloader_map_define)

# 预先创建目录
dir_list = [log_dir, conf_dir, site_common_dir, site_custom_dir, cache_unfolder_dir]
for d in dir_list:
    if not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)


# 准备好logger
def give_me_a_logger(logger_name, formatter_str,  logger_file_name="", console=True, need_rotate=True, backup=10):
    # logging简单的封装
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter(formatter_str)
    log_file_path = jj(log_dir, logger_file_name)
    if logger_file_name:  # 需要文件日志
        if need_rotate:
            fh = RotatingFileHandler(
                log_file_path, maxBytes=1024*1024*5, backupCount=backup)
        else:
            fh = logging.FileHandler(log_file_path, encoding='utf-8')
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    if console:  # console输出
        ch = logging.StreamHandler()
        ch.setLevel(logging.DEBUG)
        ch.setFormatter(formatter)
        logger.addHandler(ch)
    return logger


# 运行日志
logger = give_me_a_logger(
    "mainlogger", "%(asctime)s - %(filename)s [line:%(lineno)d] - %(levelname)s: %(message)s", 'crawler.log')

# 进展日志的字典
plogger_dict = {}

opener = urllib.request.build_opener()

# 默认配置项
default_conf = {
    "mitm_port": "19820",  # mitmproxy的端口号
    "server_need": True,  # 需要连接服务器的、鉴权等等
    "server_address":"",  # 连接的中心节点的地址 如果server_need为True，本参数为空，报错，结束
    "use_proxy": False,  # 是否用proxy开启webdriver
    "use_huawei_login_chrome": False,  # 是否在webdriver中访问w3.huawei.com的登录
    "proxy": "127.0.0.1:10809",  # proxy地址
    "network_test_url":"huawei.com",
    # 是否使用鉴权的proxy模式。和use_huawei_login_chrome参数一样处理，如果具体任务配置中开启了这个参数，并且也能获取用户名、密码的情况，才会使用鉴权proxy模式的opener。主要用于访问外网
    "use_auth_proxy": False,
    "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.164 Safari/537.36",
    "unfolder_map": {},
    "downloader_map": {},
    "debug_mode": False,
    "headless_mode": True,
    "socket_timeout": 15,
    "process_link_threads": 4,   # 遍历、处理展开后链接的线程数
    "url_download_threads": 10,  # url_download 下载的线程数
    "cache_unfold_last_days": 3,  # 展开器缓存的天数
    "chrome_path": "",     # chrome的path
    "chromedriver_auto_update": True  # 会自动检测当前系统的chrome的版本号，自动升级chromedriver
}


def default_conf_to_sharedobj():
    # 用默认配置初始化
    logger.info("[系统默认参数值]:")
    for key in default_conf:
        setattr(shared_obj, key, default_conf[key])
        logger.info("    " + key + " : " + str(default_conf[key]))


def get_settting_from_shareobj():
    # 从shareobj中把所有key输出出来
    data = {}
    for key in default_conf:
        data[key] = getattr(shared_obj, key)
    return data


def read_sys_conf_to_sharedobj():
    # 读这个工具的整体配置，把配置刷到shared_obj里面
    # 在没有ui的情况下，只有启动的时候做一次，运行过程中修改配置文件先不生效吧。
    
    if not os.path.isfile(sys_conf_file):
        logger.info("[警告][方法]:" + func_name() +
                    " |找不到配置文件, 生成默认配置文件：" + sys_conf_file)
        with open(sys_conf_file, 'w', encoding='utf8') as f:
            f.write(json.dumps(default_conf, ensure_ascii=False, indent=4))
        return True, 'ok'

    r,msg,data = load_json_file(sys_conf_file)
    if not r:
        return False,msg

    logger.info("[配置文件参数值]:")
    for key in data:
        if key == "proxy" and "http" in data[key]:
            data[key] = rm_protocol_pre(data[key])
    
        setattr(shared_obj, key, data[key])
        logger.info("    " + key + " : " + str(data[key]))

    # if fix_flag:  # 有自动修改，刷新一下
    #     
    print("[配置文件刷新]")
    data = get_settting_from_shareobj()
    save_json_file(sys_conf_file, data)

# 下面这几个方法为了可以运行时临时修改具体的参数--但是有这个必要吗？调试的时候用到了， 先留着
# 期待非开发者用户的普通的用法应该就是通过配置文件（后续有界面，就用界面）跑任务的时候重读一下配置文件，
# 或者把配置文件注入到redis里面去（当没用redis之前，就重新加载一下配置文件到shared_obj里面）


def set_debug(stat):
    # 设置debug模式状态
    shared_obj.debug_mode = stat


def set_headless(stat):
    # 设置无头模式
    shared_obj.headless_mode = stat


def use_proxy(stat):
    # 使用proxy
    shared_obj.use_proxy = stat
    r, msg = set_opener(stat)
    if not r:
        logger.info(msg)

    return r, msg


def set_proxy(proxy_str):
    # 设置proxy值
    shared_obj.proxy = proxy_str
    if proxy_str:
        use_proxy(True)


def set_opener(use_proxy, use_auth="use_config"):
    # shared_obj.use_auth_proxy):
    # stat 表示用proxy
    global opener
    if use_proxy:
        if use_auth == False or (use_auth == "use_config" and not shared_obj.use_auth_proxy):
            proxy_support = urllib.request.ProxyHandler(
                {'http': "http://"+shared_obj.proxy, 'https': "http://"+shared_obj.proxy})
            opener = urllib.request.build_opener(proxy_support)
        else:
            r, msg, usr, pwd = get_account()
            if not r:
                return r, msg

            auth_str = gen_escaped_user_pwd_str(usr, pwd)
            proxy_str = "http://" + auth_str + shared_obj.proxy
            proxy_support = urllib.request.ProxyHandler(
                {'http': proxy_str, 'https': proxy_str})
            opener = urllib.request.build_opener(
                proxy_support, request.HTTPBasicAuthHandler(), urllib.request.HTTPHandler)
    else:
        opener = urllib.request.build_opener()

    # print(shared_obj.ua)
    opener.addheaders = [('User-agent', shared_obj.ua)]
    urllib.request.install_opener(opener)
    return True, 'ok'


def load_processed_url(define_id):
    # 已经完成的url： 返回processed.log中的减去 failed.log中的记录
    plog_path = jj(log_dir, define_id + '_processed.log')
    flog_path = jj(log_dir, define_id + '_failed.log')
    if os.path.isfile(plog_path):
        with open(plog_path, 'r', encoding='utf8') as f:
            p_list = [l.strip() for l in f.read().split("\n") if l.strip()]
    else:
        return []

    if os.path.isfile(flog_path):
        with open(flog_path, 'r', encoding='utf8') as f:
            f_list = [l.strip() for l in f.read().split("\n") if l.strip()]
    else:
        f_list = []

    return list(set(p_list) - set(f_list))


def unfold_and_process(start_url, max_time_for_starting=5, check_downloaded=True):
    # 底部展开、下载一套完成
    r, msg, all_link_list, define_id = bottom_unfold(start_url)
    if not r:
        logger.error(msg)
        return r, msg

    p_urls = load_processed_url(define_id)

    filter_link_list = []  # 过滤出的还未处理的link

    for idx, link_obj in enumerate(all_link_list):
        url = link_obj.get('url', "")
        unfold_meta = link_obj.get('meta', "")

        if not url:
            logger.info("[错误][方法]:" + func_name() +
                        " |unfold后，发现url为空：" + str(idx))
            continue

        if url in p_urls and check_downloaded:
            logger.info('[skip]已经下载过:' + url)
            continue

        filter_link_list.append(
            [url, unfold_meta, define_id, max_time_for_starting])
        # r, msg = process_link(url, unfold_meta, define_id, max_time_for_starting)
    executor = ThreadPoolExecutor(max_workers=shared_obj.process_link_threads)
    all_task = [executor.submit(
        process_link, f[0], f[1], f[2], f[3]) for f in filter_link_list]
    wait(all_task, return_when=ALL_COMPLETED)

    p_urls = load_processed_url(define_id)
    msg = "[结束]完成爬取。(" + str(p_urls) + "/" + str(filter_link_list) + ")"
    logger.info(msg)
    return True, msg


def json_unfold(start_url):
    # json展开器
    pass


def tree_unfold(start_url):
    # 树装的展开器， 文档类的站点的爬取可以用这个
    pass


def bottom_unfold(start_url):
    # 这种展开器：bottom unfold，底部展开。
    # 根据定义将url展开
    global plogger_dict

    if not shared_obj.unfolder_map:
        r, msg, shared_obj.unfolder_map = get_unfolder_map()
        if not r:
            logger.error(msg)
            return r, msg, '', ''

    r, msg, matched_define = get_matched_define(
        shared_obj.unfolder_map, start_url)
    if not r:
        logger.error(msg)
        return r, msg, '', ''

    if not matched_define:  # 没匹配上的先包装起来
        link_dict = {}
        link_dict['url'] = start_url
        link_dict['unfoldered'] = False
        return True, 'ok', [link_dict], ''

    define_id = matched_define.get('define_id', "")
    plogger_dict[define_id] = [
        give_me_a_logger(
            "process_logger", "%(message)s", define_id + '_processed.log', console=False, need_rotate=False),
        give_me_a_logger(
            "faided_logger", "%(message)s", define_id + '_failed.log', console=False, need_rotate=False)
    ]

    # 尝试拿缓存, 如果成功，直接跳过，return
    r, msg, all_link_list = load_unfold_cache(matched_define, start_url)
    if r and all_link_list:  # 拿到缓存了
        return r, msg, all_link_list, define_id

    no_image_flag = matched_define.get("no_image", True)
    use_huawei_login_chrome = matched_define.get(
        "huawei_login", shared_obj.use_huawei_login_chrome)
    use_proxy = matched_define.get("use_proxy", shared_obj.use_proxy)
    cookie_str = matched_define.get('cookie', "")
    headless_mode = matched_define.get(
        "headless_mode", shared_obj.headless_mode)

    r, msg, driver = get_driver(
        no_image=no_image_flag, use_huawei_login_chrome=use_huawei_login_chrome, use_proxy=use_proxy, headless_mode=headless_mode)

    if not r:
        return r, msg, '', define_id

    driver.get(start_url)
    if cookie_str:
        r, msg, driver = load_cookie(driver, cookie_str)
        if not r:
            return r, msg, "", define_id
        driver.refresh()

    frame_set_idx = int(matched_define.get("frame_set_idx", -1))
    link_ele_sel = matched_define.get('link_ele')

    next_page_ele_sel = matched_define.get("next_page_ele", "")  # 翻页元素sel
    unfold_meta_defines = matched_define.get(
        'unfold_meta', [])  # 收集的unfold meta定义
    need_scroll_down = matched_define.get('scroll_down', 0)  # 向下滚动 次数
    remove_ele_sels = matched_define.get('remove_eles', [])  # 删除元素sels
    stop_max_idx = matched_define.get(
        'stop_max_idx', -1)  # 展开获取链接的max值，到了就停，-1表示没限制
    stop_max_page = matched_define.get(
        'stop_max_page', -1)  # 展开页面的max值，到了就停， -1表示没限制
    click_sels = matched_define.get(
        "if_sels_exist_then_click", [])  # 有些时候展开不只是值底部那种翻页，

    error_msg = ""

    total_idx = -1  # 记录当前展开链接的的idx值, 为了习惯，修正起始值，让idx从0开始吧
    total_page_idx = -1  # 记录当前page数量，从0开始

    not_finish_flag = True
    while not_finish_flag:
        total_page_idx += 1
        if stop_max_page != -1:  # 启用展开页限制
            if total_page_idx >= stop_max_page:
                logger.info("[提示]展开max page完成：" + str(stop_max_page))
                break

        logger.info("[正在展开]:" + driver.current_url)

        # 每个页面都要先考虑滚
        for _ in range(need_scroll_down):
            scroll_down(driver)

        # 删掉某些元素
        for rm_sel in remove_ele_sels:
            check_remove_element(driver, rm_sel, 10)

        tmp_link_list = []

        # 每一页都尝试切换一次
        if frame_set_idx >= 0:
            driver.switch_to.parent_frame()
            driver.switch_to.frame(frame_set_idx)

        r, msg, link_eles = wait_eles(driver, link_ele_sel)

        for link_ele in link_eles:
            total_idx += 1
            if stop_max_idx != -1:
                if total_idx >= stop_max_idx:
                    logger.info('[提示]展开max idx完成：'+str(stop_max_idx))
                    not_finish_flag = False
                    break

            new_obj = {}
            single_meta_dict = {}
            href = link_ele.get_attribute("href")
            if not href:
                logger.info("[错误][方法]:" + func_name() +
                            " |在href属性中没有url链接：" + driver.current_url)
                continue

            href = check_abs_url(driver.current_url, href)
            new_obj['url'] = href
            tmp_link_list.append(new_obj)

            for idx, unfold_meta_define in enumerate(unfold_meta_defines):
                value = ""
                # unfold_meta这种，必定是相对于链接元素获得的meta数据
                # 或者关于这个连接的idx值
                meta_name = unfold_meta_define.get("name", "")
                r, msg, redirect_flag, value = meta_define_2_value(
                    driver, unfold_meta_define, {}, base_ele=link_ele)
                if not r:
                    error_msg += "\n" + msg
                    logger.info(msg)
                    # 展开的过程不涉及复杂的页面交互，所以先不检查redirect这个问题
                    continue

                single_meta_dict[meta_name] = value

            # 这种是自动生成的元数据，以auto开头
            single_meta_dict['auto_idx'] = total_idx
            single_meta_dict['auto_parent_page_url'] = driver.current_url

            if single_meta_dict:
                new_obj['meta'] = single_meta_dict

            all_link_list.append(new_obj)

            if shared_obj.debug_mode:
                print(new_obj)

        if not not_finish_flag:
            break

        if not next_page_ele_sel:
            logger.info("[提示]翻页元素选择器为空，将不会继续翻页。")
            break

        r, msg, next_page_ele = wait_clickable_ele(driver, next_page_ele_sel)
        if r:
            next_page_ele.send_keys("\n")  # 用回车点击可以防止被元素挡住
            time.sleep(1)  # 翻页的时候要等一下，不然有可能拿到上一个页面的元素
        else:
            break

    logger.info("[完成展开]:" + start_url +
                " [获取目标链接个数]：" + str(len(all_link_list)))
    driver.quit()
    save_unfold_cache(matched_define, all_link_list, start_url)  # 成功后缓存一下
    return True, 'ok', all_link_list, define_id


def merge_meta_to_main_meta(meta_dict, main_meta_dict):
    # 将各种meta合到主meta字典中。
    # 这样的好处是，在一个页面的不同的阶段，可以使用全局的meta值。
    # 目前可能包含unfold_meta, sub_meta, page_meta
    for key in meta_dict:
        if key in main_meta_dict:
            logger.info("[警告]跳过冲突的meta key:" + key)
            continue
        main_meta_dict[key] = meta_dict[key]
    return main_meta_dict


def process_link(url, unfold_meta, unfold_define_id, max_time_for_starting=5):
    # 处理具体目标url中的信息

    # 获取downloader_map中的匹配的配置
    if not shared_obj.downloader_map:
        r, msg, shared_obj.downloader_map = get_downloader_map()
        if not r:
            logger.info(msg)
            return r, msg

    r, msg, matched_define = get_matched_define(shared_obj.downloader_map, url)
    if not r:
        logger.info(msg)
        return r, msg

    if not matched_define:
        msg = "[错误][方法]:" + func_name() + " |没有找到适合站点的定义：|" + url + "|"
        logger.info(msg)
        return False, msg

    logger.info("[开始]尝试下载:" + url)

    # 本url下载过程中的整体meta字典，unfold_meta、main_meta字段中的都要合进来
    # sub_meta、down_meta 表示在目标页面，点击下载的对象、链接下载对象过程中收集的元数据，这种元数据主要用于文件下载时，下载文件名的拼装，瓶装完就没用，一般有多个，就不记录到main_meta中了。
    main_meta = {}
    main_meta = merge_meta_to_main_meta(
        unfold_meta, main_meta)  # 合入unfold_meta

    # 创建下载临时目录，用完记得清理
    if not os.path.isdir(tmp_root_dir):
        os.makedirs(tmp_root_dir, exist_ok=True)
    temp_dir = tempfile.TemporaryDirectory(
        "_folder", 'downloader_', tmp_root_dir)
    temp_dir_path = temp_dir.name

    no_image_flag = matched_define.get("no_image", True)
    use_huawei_login_chrome = matched_define.get(
        "huawei_login", "use_config")
    use_proxy = matched_define.get("use_proxy", shared_obj.use_proxy)
    headless_mode = matched_define.get(
        "headless_mode", shared_obj.headless_mode)

    # 获取driver
    r, msg, driver = get_driver(
        temp_dir_path=temp_dir_path, no_image=no_image_flag, use_huawei_login_chrome=use_huawei_login_chrome, use_proxy=use_proxy, headless_mode=headless_mode)
    if not r:
        return r, msg

    define_desc = matched_define.get('desc', "")
    main_meta_defines = matched_define.get(
        'main_meta', [])  # download页面的主元数据定义
    # 通过点击下载目标列表， 如果要下载那种点击后，自动下载的，通过这种
    download_define_list = matched_define.get('downloads', [])
    html_down_list = matched_define.get("save_htmls", [])  # 需要下载html文件的列表

    r, msg = try_get_url(driver, url)
    if not r:
        return r, msg

    # 处理 main_meta
    # main meta 和click meta 差不多，只是不是rel_sel，而是sel，直接从sel选中的元素上拿数据
    if main_meta_defines:
        r, msg, new_meta_dict = process_main_meta(
            driver, main_meta_defines, copy.deepcopy(main_meta))

        if shared_obj.debug_mode:
            print('[[[[main_meta_defines]]]]', main_meta_defines)
            print('[[[main_meta]]]', main_meta)
            print(r, msg, new_meta_dict)
        if not r:
            logger.info(msg)
            driver.quit()
            return r, msg

        main_meta = merge_meta_to_main_meta(new_meta_dict, main_meta)
        if shared_obj.debug_mode:
            print(main_meta)

    # target_folder是在download_root_dir下的路径，用来分目录存放下载对象。
    target_folder_list = matched_define.get('target_folder_name', [])
    if target_folder_list:
        target_folder_name = meta_value_to_str(
            main_meta, target_folder_list).replace(":", "_")
        # print("download_root_dir:", download_root_dir)
        # print("target_folder_name:", target_folder_name)
        target_path = windows_path_filter(os.path.abspath(
            jj(download_root_dir, target_folder_name)))
        logger.info("[download target_path]:" + target_path)
    else:
        target_path = download_root_dir  # 如果没配置就下载到根目录

    if not os.path.isdir(target_path):
        os.makedirs(target_path, exist_ok=True)

    # 处理页面下载
    if html_down_list:
        pass

    # 处理download
    if download_define_list:
        r, msg = process_downloads(
            driver, download_define_list, copy.deepcopy(main_meta), temp_dir_path, target_path, max_time_for_starting, url, unfold_define_id)
        if not r:
            logger.info(msg)
            driver.quit()
            return r, msg

    temp_dir.cleanup()
    driver.quit()
    plogger_dict[unfold_define_id][0].info(url)  # 记录成功的url
    return True, msg


# def process_html_save(driver, ,main_meta)


def try_get_url(driver, url, url_retry_max=10):
    # 对于不稳定页面的get，要用这种
    suc_flag = False
    while url_retry_max:
        try:
            driver.get(url)
            suc_flag = True
            break
        except Exception as ex:
            msg = "[警告][方法]:" + func_name() + " |webdriver跳转过慢|" + url + "|" + \
                str(url_retry_max) + "|" + \
                except_msg(ex, "")
            logger.info(msg)
            url_retry_max -= 1

    if not suc_flag:
        # 这里如果超时了，超过了失败次数的限制，也不会在plogger里记录，所以问题不大
        msg = "[错误][方法]:" + func_name() + " |页面超时|" + url + "|"
        logger.info(msg)
        driver.quit()
        return False, msg
    else:
        return True, 'ok'


def process_main_meta(driver, main_meta_defines, main_meta):
    # 处理main meta
    # main_meta 因为暂时是静态获取的（无动作交互）——所以先忽略页面跳转的情况

    meta_dict = {}
    for define in main_meta_defines:
        name = define.get('name', '')
        r, msg, _, value = meta_define_2_value(driver, define, main_meta)
        if not r:
            # logger.info(msg)
            return False, msg, {}

        if name in meta_dict:
            msg = "[错误][方法]:" + func_name() + " |main_meta定义有重复的name字段:" + name
            logger.info(msg)
            return False, msg, {}
        meta_dict[name] = value

    return True, 'ok', meta_dict


def process_downloads(driver, download_define_list, sub_main_meta, temp_dir_path, target_path, max_time_for_starting, url, unfold_define_id):
    # 处理下载任务

    # 在这个任务里，不会增量收集main_meta；
    # 但会把先前已经收集的main_meta传入供这个任务使用

    error_msg = ''
    success_idx_list = []
    failed_idx_dict = {}
    for download_define in download_define_list:
        sel = download_define.get("sel", "")
        if not sel:
            # click下载、url下载都要首先有个元素
            return False, "[错误][方法]:" + func_name() + " |下载定义中，sel不能为空："+json.dumps(download_define), ""

        sub_meta_defines = download_define.get('sub_meta', [])
        filename_defines = download_define.get('file_name', [])
        download_method = download_define.get(
            'method', "click")  # 目前有两种"click"、"url"

        use_proxy = download_define.get("use_proxy", shared_obj.use_proxy)
        if use_proxy == "use_config":
            use_proxy = shared_obj.use_proxy

        use_auth_proxy = download_define.get(
            "use_auth_proxy", shared_obj.use_auth_proxy)

        # url_download_threads = download_define.get(
        #     "url_download_threads", shared_obj.url_download_threads)
        # 这个配置项之前是打算也放在download_map配置文件里面的，但是后来想想，这个和业务是不强相关的，而和每个人的机器性能、当前是否在处理其他任务相关（就是对同一个下载任务而言，这个参数的配置是允许不一样的）；process_link 也同理
        url_download_threads = shared_obj.url_download_threads

        if download_method == "url":
            download_url = download_define.get('url_path', [])
            if not download_url:
                return False, "[错误][方法]:" + func_name() + " |下载定义中，当method为url时，url_path字段不能为空："+json.dumps(download_define), ""

        r, msg, eles = wait_eles(driver, sel)
        if not r:
            error_msg += "\n" + msg
            logger.info(msg)
            continue

        idx = 0

        redirect_flag = False

        batch_url_download_list = []  # 准备开多线程下载的list

        while idx < len(eles):
            if idx in success_idx_list or idx in failed_idx_dict:
                idx += 1
                continue

            ele = eles[idx]
            for sub_meta_define in sub_meta_defines:
                value = ""
                meta_name = sub_meta_define.get('name', "")

                r, msg, redirect_flag, value = meta_define_2_value(
                    driver, sub_meta_define, sub_main_meta, base_ele=ele)
                if not r:
                    if redirect_flag:
                        r, msg, eles, driver = redirect_page(driver, url, sel)
                        break
                    else:
                        continue

                # downloads的meta往往会比较多，数量不可控，sub_meta的主要用途还是获取关键信息，然后处理后用于下载文件的文件名的拼装，这个meta对整个页面来说公共价值较少。
                # 所以不要合入到main_meta里面。
                sub_main_meta[meta_name] = value

            if redirect_flag:
                redirect_flag = False
                continue

            if filename_defines:
                file_name = windows_name_filter(
                    meta_value_to_str(sub_main_meta, filename_defines))
                print(sub_main_meta, filename_defines, file_name)
            else:
                file_name = ""  # 不定义filename_defines就会用原来的文件名

            if download_method == "click":
                ele.click()
                r, msg = move_chrome_downloaded(
                    temp_dir_path, target_path, file_name, max_time_for_starting, url)

                if r:
                    success_idx_list.append(idx)
                    idx += 1
                else:
                    # 下载失败了， 就重定向页面回url，然后重新获取eles
                    if idx not in failed_idx_dict:
                        failed_idx_dict[idx] = 0
                    else:
                        failed_idx_dict[idx] += 1

                    logger.info(msg)
                    r, msg, eles, driver = redirect_page(driver, url, sel)
                    if not r:
                        error_msg += "\n" + msg
                        logger.error(msg)
                        break
            else:  # "url"
                url_path = meta_value_to_str(sub_main_meta, download_url)
                url_path = check_abs_url(driver.current_url, url_path)

                batch_url_download_list.append(
                    [target_path, file_name, url_path, max_time_for_starting, url, unfold_define_id])
                success_idx_list.append(idx)
                idx += 1

        if batch_url_download_list:
            r, msg = batch_url_download(
                batch_url_download_list, use_proxy, use_auth_proxy, url_download_threads)

    return True, error_msg


def batch_url_download(batch_url_download_list, use_proxy, use_auth_proxy, url_download_threads):
    # 线程池调用url_download, 这个方法抽出来，可以直接给其他的展开器重用
    r, msg = set_opener(use_proxy, use_auth_proxy)
    set_socket_timout(shared_obj.socket_timeout)

    if not r:
        logger.info(msg)
        return False, msg

    executor = ThreadPoolExecutor(max_workers=url_download_threads)
    all_task = [executor.submit(
        url_download, f[0], f[1], f[2], f[3], f[4], f[5]) for f in batch_url_download_list]
    wait(all_task, return_when=ALL_COMPLETED)
    return True, 'ok'


def url_download(target_path, file_name, url_path, max_time_for_starting, parent_url, unfold_define_id=""):
    # 通过url下载文件，适合图片文件不通过在chrome中点击下载的对象
    remote_file_name = os.path.basename(url_path)
    if not remote_file_name:
        msg = "[错误][方法]:" + func_name() + " |url中缺少有效的文件路径:" + \
            url_path + "| parent_url:" + parent_url
        logger.info(msg)
        if unfold_define_id:
            plogger_dict[unfold_define_id][1].info(parent_url)  # 记录失败日志
        return False, msg

    if not file_name:
        file_name = remote_file_name

    if not os.path.isdir(target_path):
        os.makedirs(target_path, exist_ok=True)

    file_path = jj(target_path, windows_name_filter(file_name))

    while max_time_for_starting > 0:
        try:
            urllib.request.urlretrieve(url_path, file_path)
            # print('ok:'+ url_path)
            break
        except Exception as ex:
            msg = "[错误][方法]:" + func_name() + " |urlretrieve异常|" + url_path + "|" + \
                str(max_time_for_starting) + "|" + \
                except_msg(ex, "") + " | parent_url:" + parent_url
            logger.info(msg)
            max_time_for_starting -= 1
            print("尝试剩余次数:", max_time_for_starting)
            continue

    if os.path.isfile(file_path):
        return True, 'ok'
    else:
        if unfold_define_id:
            plogger_dict[unfold_define_id][1].info(parent_url)  # 记录失败日志
        return False, 'faild'


def click_ele_by_sels(click_ele_sels, driver):
    # 根据传入sels列表，依次点击
    # 从第二个ele开始，允许使用相对selector
    msg = "ok"
    last_ele = ""
    for sel in click_ele_sels:
        if sel.startswith("[xpath]./"):  # 在普通sel字段里，只有这样才是相对查找
            if not last_ele:
                msg = "[错误][方法]:" + func_name() + \
                    " |在clicks的配置中，第一个元素不能用xpath元素"
                return False, msg
            else:
                r, msg, ele = find_rel_ele(last_ele, sel)
        else:
            r, msg, ele = wait_ele(driver, sel)
            if not r:
                return r, msg

        last_ele = ele
        ele.click()
        time.sleep(1)  # 点了后等一下

    return True, msg


def meta_define_2_value(driver, meta_define, main_meta, base_ele=""):
    # 从元数据定义，根据实际情况，求值
    # 元数据有两种:
    # 1.从元素的meta定义得到value值。一般是根据sel去拿值，如果是相对元素，则要传入base_ele。
    # 2.已有元数据（已有的元数据的define要写在这个define的前面）经过post_processes得到的新数据。

    redirect_flag = False  # 页面要重定向
    value = ""  # 最终要输出的value
    msg = ""

    meta_name = meta_define.get('name', '')
    if not meta_name:
        msg = "[错误][方法]:" + func_name() + " |meta定义的name字段为空：" + \
            json.dumps(meta_define)
        logger.info(msg)
        return False, msg, redirect_flag, value

    meta_type = meta_define.get('type', 'text')

    if base_ele:
        sel = meta_define.get('rel_sel', '')
    else:
        sel = meta_define.get('sel', '')

    post_processes = meta_define.get('post_processes', [])
    click_ele_sels = meta_define.get('clicks', [])  # 依次点击各个元素
    r, msg = click_ele_by_sels(click_ele_sels, driver)
    if not r:
        logger.info(msg)
        if "StaleElementReferenceException" in msg:  # 说明页面跳转了
            redirect_flag = True
        return False, msg, redirect_flag, value

    if meta_type in ["text", "html", "pre_ele_text", "attr"]:
        # 根据元素拿值
        if not sel:
            msg = "[错误][方法]:" + func_name() + " |在使用text模式的meta定义时，没有传入有效的sel或rel_sel:" + \
                json.dumps(meta_define)
            logger.info(msg)
            return False, msg, redirect_flag, value

        if base_ele:
            r, msg, ele = find_rel_ele(base_ele, sel)
        else:
            r, msg, ele = wait_ele(driver, sel)

        if not r:
            logger.info(msg)
            return False, msg, redirect_flag, value

        value = ele_2_meta_value(
            ele, meta_define, main_meta, post_processes, driver)

    elif meta_type == "sum":
        # 求找到元素数量的和， value是int
        if base_ele:
            r, msg, ele = find_rel_eles(base_ele, sel)
        else:
            r, msg, ele = wait_eles(driver, sel)

        if not r:
            logger.info(msg)
            return False, msg, redirect_flag, value

        value = value_to_post(len(ele), post_processes, main_meta, meta_type)

    elif meta_type == "meta":  # 基于已有main_meta
        meta_name = meta_define.get('meta_name', '')
        value = main_meta.get(meta_name, '')
        value = value_to_post(value, post_processes, main_meta, meta_type)

    return True, 'ok', redirect_flag, value


def ele_2_meta_value(rel_ele, meta_define, main_meta, post_processes, driver):
    # 从元素得到value值
    # 被上面的meta_define_2_value调用

    value = ""
    meta_type = meta_define.get('type', 'text')
    if meta_type == 'text':  # 里面包含的所有文本
        value = rel_ele.text
    elif meta_type == "text_no_sub":  # 不包含子元素的文本
        value = get_text_excluding_children(driver, rel_ele)
    elif meta_type == 'html':  # 元素包含的html
        value = rel_ele.get_attribute("outerHTML")
    elif meta_type == "attr":  # 指定的属性字符串
        attri_name = meta_define.get('field', '')
        value = rel_ele.get_attribute(attri_name)
    elif meta_type == "pre_ele_text":  # 前一个元素的文本
        value = get_previous_sibling_text(driver, rel_ele)

    value = meta_str_clean(value)
    return value_to_post(value, post_processes, main_meta, meta_type)


def value_to_post(value, post_processes, main_meta, meta_type):
    # 返回经过post_process处理的value
    return meta_str_clean(post_process_eval(value, post_processes, main_meta, meta_type))


def redirect_page(driver, url, sel):
    # 页面肯能跳转后，尝试用这个重新跳回url，并重新选中需要的元素（们）
    driver.get(url)
    time.sleep(1)
    r, msg, eles = wait_eles(driver, sel)
    return r, msg, eles, driver


def meta_str_clean(meta_str):
    # 清理meta 字符串中各种无用的空白字符
    return meta_str.replace("\n", "").replace("\t", "").strip(" ")


def meta_value_to_str(meta_dict, output_list):
    # 从meta value字典合成出最后需要的str
    result_str = ""
    for output in output_list:
        if output.startswith("[meta]"):
            value = meta_dict.get(output.replace("[meta]", "", 1), "")
        else:
            value = output
        result_str += value
    return meta_str_clean(result_str)


def post_process_eval(value, post_processes, main_meta, meta_type):
    # 处理post_processes这种结构对字符串的简单配置式的操作
    # 单独抽出来，便于重用
    value = str(value)

    for post_process in post_processes:
        # print("#######in#########", value)
        process_name = post_process.get("name", '')
        if not process_name:
            error_msg += "\n" + "[错误][方法]:" + \
                func_name() + " |post_processes的name不能为空"
            continue

        process_value = post_process.get('value', {})
        if process_name in ["split", 'rsplit']:
            # split
            splitor = process_value.get("splitor", "")
            split_times = process_value.get("count", -1)
            joinor = process_value.get("joinor", "")
            if process_name == 'split':
                split_res = value.split(splitor, split_times)
            else:
                split_res = value.rsplit(splitor, split_times)

            len_part = len(split_res)
            join_idxs = process_value.get("join_idxs", [])
            new_join_idxs = []
            for j in join_idxs:
                if j >= 0:
                    new_join_idxs.append(j)
                else:
                    new_join_idxs.append(j+len_part)

            find_res = []
            for idx, part in enumerate(split_res):
                if idx in new_join_idxs:
                    find_res.append(part)
            value = joinor.join(find_res)

        elif process_name == "zfill":
            # 左侧补零
            length = post_process.get('length', 0)
            value = value.zfill(length)

        elif process_name == "replace":
            # 从左侧开始替换

            re_from = process_value.get("from", "")
            re_to = process_value.get("to", "")
            re_times = int(process_value.get("times", -1))
            # print(value, re_from, re_to, re_times)
            value = value.replace(re_from, re_to, re_times)
        elif process_name == "rreplace":
            # 从右侧开始替换
            re_from = process_value.get("from", "")
            re_to = process_value.get("to", "")
            re_times = int(process_value.get("times", -1))
            value = rreplace(value, re_from, re_to, re_times)
        elif process_name == "strip":
            # strip
            value = value.strip("\n")
            value = value.strip("\t")

        elif process_name == "simple_chinese":
            # 转换成简体中文
            value = convert_to_simple_chinese(value)

        elif process_name == "plus":
            # 加法
            plus_object = process_value.get("plus_oject", "0")

            try:
                value = int(value)
            except:
                value = 1000  # 转失败了就1000开始
        # print("#######out#########", value)
        elif process_name == "remove_eles":
            # 从当前value所代表的树结构中删除掉指定的元素
            if meta_type in ['html']:  # 只有为html类型的时候，才会生效！
                doc = pq_fix(value)
                rm_css_sel_list = process_value.get("remove_eles", [])
                for sel in rm_css_sel_list:
                    doc.remove(sel)
                value = doc.html()

    return value


def one_of_list_endswith_suffix(file_list, suffix):
    for f in file_list:
        if f.endswith(suffix):
            return True
    return False


def move_chrome_downloaded(download_path, target_folder, file_name, max_time_for_starting=5, url=""):
    # 监控chrome下载目录，将chrome下载的文件移动到指定目录
    got_file = False
    current_time = 0
    while got_file == False:
        finds = glob.glob(jj(download_path, "*"))
        has_cr = one_of_list_endswith_suffix(finds, 'crdownload')
        has_tmp = one_of_list_endswith_suffix(finds, "tmp")
        if len(finds) == 0:  # 啥文件都没下载到
            if current_time >= max_time_for_starting:
                msg = "[失败]文件不能下载:" + file_name + "  url:" + url
                return False, msg
            time.sleep(1)
            current_time += 1
            continue
        elif has_cr or has_tmp:
            time.sleep(1)
            continue
        else:
            got_file = True

    if not file_name:
        file_name = os.path.basename(finds[0])

    file_name = windows_name_filter(file_name)  # windows文件名的规范性
    target_file = jj(target_folder, file_name)

    renamed_flag = False
    while not renamed_flag:
        try:
            if os.path.isfile(target_file):
                os.remove(target_file)

            os.rename(finds[0], target_file)
            renamed_flag = True
        except Exception as ex:
            msg = except_msg(ex, "[稍等]:")
            logger.info(msg)
            time.sleep(1)

    msg = "[成功]下载到:" + target_file
    logger.info(msg)
    return True, msg


def load_cookie(driver, cookie_str):
    # 尝试给driver加载cookie
    try:
        cookies = json.loads(cookie_str)
    except Exception as ex:
        msg = "[错误]cookie 格式有误：" + cookie_str
        logger.info(msg)
        return False, msg, driver

    for cookie in cookies:
        driver.add_cookie(cookie)
    return True, 'ok', driver


def get_login_cookie():
    # 弹出个chrome，用户手工登录，然后收集login后cookie，打印出来
    info_str = subprocess.check_output(
        [simple_ui_bin_path, "--act", "input"]).decode().strip()

    r, msg, driver = get_driver(no_image=False, headless_mode=False)
    if not r:
        logger.info(msg)
        return

    print("info_str：", info_str)
    driver.get(info_str)
    time.sleep(3)
    _ = subprocess.check_output(
        [simple_ui_bin_path, "--act", "info1"]).decode().strip()
    cookie = driver.get_cookies()
    cookie_str = json.dumps(cookie, ensure_ascii=False)

    copy_str_to_clipboard(cookie_str)
    print(cookie_str)
    return


def input_ctrl_v_enter():
    # 注意这种不能在锁屏下使用
    win32api.keybd_event(17, 0, )  # ctrl
    win32api.keybd_event(86, 0,)  # v
    win32api.keybd_event(17, 0, 2, )  # release ctrl
    win32api.keybd_event(13, 0,)  # enter


def copy_str_to_clipboard(content):
    # 注意这种不能在锁屏下使用    
    # string 到剪贴板
    win32clipboard.OpenClipboard()
    win32clipboard.EmptyClipboard()
    win32clipboard.SetClipboardText(content, win32clipboard.CF_TEXT)
    win32clipboard.CloseClipboard()


def check_command(command):
    # 检查注册表中的字段o不ok
    command = command.strip()
    if not command.endswith(".exe"):
        command = shlex.split(command)[0]  # 分割一下
        if not command.endswith(".exe"):
            return ""  # 没找到

    if os.path.isfile(command):  # 好就是了
        return command
    else:
        return ""


def find_exe_in_registry():
    # 尝试在注册表里找chrome.exe的安装路径
    try:
        from _winreg import OpenKey, QueryValue, HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER
    except ImportError:
        from winreg import OpenKey, QueryValue, HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER
    import shlex
    keys = (r"SOFTWARE\Classes\chromeHTML\shell\open\command",
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe")
    command = ""

    for path in keys:
        try:
            key = OpenKey(HKEY_LOCAL_MACHINE, path)
            command = check_command(QueryValue(key, ""))
            if command:
                break
        except OSError:
            try:
                key = OpenKey(HKEY_CURRENT_USER, path)
                command = check_command(QueryValue(key, ""))
                if command:
                    break
            except OSError:
                pass
    else:
        return ""

    if not command:
        return ""
    else:
        return command


def get_chrome_version():
    # 返回chrome的版本号——主要是前两位，用于选择匹配的chromedriver.exe
    if not shared_obj.chrome_path:
        shared_obj.chrome_path = find_exe_in_registry()

    if not shared_obj.chrome_path or not os.path.isfile(shared_obj.chrome_path):
        msg = "[错误]在系统中没找到有效的chrome， 请安装chrome，或在conf/utils_conf.json中配置chrome_path参数，设置为您系统上实际存在的chrome的完整路径。"
        logger.info(msg)
        return False, msg, ''
    else:
        return True, 'ok', get_version_via_com(shared_obj.chrome_path).split(".")[0]


def get_chromedriver_version():
    # 获取chromedriver的版本号
    if not os.path.isfile(chromedriver_bin_path):
        return False

    info_str = subprocess.check_output(chromedriver_bin_path + " -v").decode()
    res = re.findall(r'.+? (\d\d)\..+?', info_str)
    if not res:
        return False
    return res[0]


def get_version_via_com(filename):
    # 通过com拿到文件的版本号，chrome可以
    parser = win32com.client.Dispatch("Scripting.FileSystemObject")
    version = parser.GetFileVersion(filename)
    return version


def check_chrome_and_driver():
    # 检查chrome和chromedriver
    r, msg, chrome_version = get_chrome_version()
    if not r:
        return r, msg  # 找不到chrome

    if shared_obj.chromedriver_auto_update == False:  # 不更新
        if os.path.isfile(chromedriver_bin_path):
            return True, 'ok'  # 当chrome.exe存在、chromedriver也存在，chromedriver不自动更新，那就返回ok
    else:  # 自动更新
        chromedriver_version = get_chromedriver_version()
        if chromedriver_version == chrome_version:
            return True, 'ok'

    r, msg = try_get_chromedriver_bin(chrome_version)
    if not r:
        return r, msg

    return True, 'ok'


def try_get_chromedriver_bin(chrome_version):
    # 尝试获取chromedriver.exe
    logger.info("[提醒]正在尝试下载和版本号为"+chrome_version+"chrome版本匹配的chromedriver")
    set_opener(use_proxy=True)
    with urllib.request.urlopen(r'https://chromedriver.storage.googleapis.com/?delimiter=/&prefix='+chrome_version) as response:
        html = response.read().decode().encode("utf-8")
        doc = pq_fix(html, parser='html')
        eles = doc("CommonPrefixes")
        for ele in eles:
            ver = pq_fix(ele).text().strip()
            if ver:
                break

    if not ver:
        msg = "[错误]没找到合适的chromedriver版本，当前chrome版本为：" + chrome_version
        logger.info(msg)
        return False, msg
    driver_name = "chromedriver_win32.zip"
    file_url = r"https://chromedriver.storage.googleapis.com/" + \
        ver + driver_name

    print(file_url)

    if not os.path.isdir(tmp_root_dir):
        os.makedirs(tmp_root_dir, exist_ok=True)
    temp_dir = tempfile.TemporaryDirectory(
        "_folder", 'downloader_', tmp_root_dir)
    temp_dir_path = temp_dir.name
    r, msg = url_download(temp_dir_path, driver_name, file_url,
                          5, "https://chromedriver.storage.googleapis.com/")

    if not r:
        return r, msg

    zip_path = jj(temp_dir_path, driver_name)
    if os.path.isfile(chromedriver_bin_path):
        logger.info("[提醒]删除原来已有的chromedriver:" + chromedriver_bin_path)
        os.remove(chromedriver_bin_path)
        print("[提醒]如果您不希望自动更新你的chromedriver，可在配置文件中设置chromedriver_auto_update的值为false")

    with zipfile.ZipFile(zip_path) as zip_ref:
        zip_ref.extractall(chromedriver_dir)

    if os.path.isfile(chromedriver_bin_path):
        logger.info('[成功]chromedriver '+ver + "下载完成。")
        return True, 'ok'

    return False, "[失败]下载失败。"


def send_req_to_devtools(driver, cmd, params={}):
    resource = "/session/%s/chromium/send_command_and_get_result" % driver.session_id
    url = driver.command_executor._url + resource
    body = json.dumps({'cmd': cmd, 'params': params})
    response = driver.command_executor._request('POST', url, body)

    if not response:
        raise Exception(response.get('value'))

    return response.get('value')


def convert_html_file_to_pdf(src_file_path, tar_file_path):
    # 将本地的html文件转为pdf文件，用webdriver操作chrome的print能力
    arguments = [
        "no-sandbox",
        "disable-gpu"
        "disable-dev-shm-usage",
    ]
    prefs = {'profile.default_content_settings': {'images': 2}}
    r, msg, driver = get_driver(pref=prefs, arguments=arguments, no_image=False, headless_mode=True)
    if not r:
        logger.info(msg)
        return False, msg
    
    src_file_path = "file:///" + src_file_path
    driver.get(src_file_path)

    try:
        WebDriverWait(driver, 2).until(EC.staleness_of(driver.find_element_by_tag_name('html')))
    except TimeoutException:
        calculated_print_options = {
            'landscape': False,
            'displayHeaderFooter': False,
            'printBackground': True,
            'preferCSSPageSize': True,
        }
        calculated_print_options.update({})
        result = send_req_to_devtools(driver, "Page.printToPDF", calculated_print_options)
        driver.quit()        
        result = base64.b64decode(result['data'])

        tar_dir = os.path.dirname(tar_file_path)
        if not  os.path.isdir(tar_dir):
            os.makedirs(tar_dir, exist_ok=True)
        
        with open(tar_file_path, 'wb') as f:
            f.write(result)

        return True, tar_file_path
    
    driver.quit()
    return False, 'wrong branch'


def get_driver(pref=None, arguments=None, max_window=True, is_debug=False, temp_dir_path="", no_image=True, use_huawei_login_chrome="use_config", use_proxy="use_config", headless_mode="use_config"):
    # 返回一个常用配置的webdriver
    if not os.path.isfile(chromedriver_bin_path):
        msg = "[错误]:" + chromedriver_bin_path + "不存在，安装包可能不完整，请重新安装"
        logger.info(msg)
        return False, msg, ""

    default_prefs = {
        'profile.password_manager_enabled': False,
        'credentials_enable_service': False
    }

    if no_image:  # 不加载图片，更快
        default_prefs["profile.managed_default_content_settings.images"] = 2

    if pref:
        if type(pref) != dict:
            msg = "[错误][方法]:" + func_name() + " |传入get_driver的pref参数需要是一个字典"
            logger.info(msg)
            return False, msg, ""
        for key in pref:
            default_prefs[key] = pref[key]

    if temp_dir_path:  # 如果传了，就配置对应的下载路径。临时目录的创建、清空在外层完成。
        default_prefs["download.default_directory"] = temp_dir_path

    options = webdriver.ChromeOptions()
    options.add_argument("--ignore-certificate-errors")

    real_headless_flag = False
    if headless_mode == True or (headless_mode == 'use_config' and shared_obj.headless_mode):
        real_headless_flag = True
    
    if real_headless_flag:
        options.add_argument('--headless')

    max_window_flag = False
    if max_window: 
        if not real_headless_flag:
            max_window_flag = True
        else:
            # 在无头模式的时候，也要把窗口撑大，否则默认的是800*600，在全屏调试时，有些element是可见的，到headless模式下，因为默认的size就会变的不可见，从而导致两种模式行为的不一致
            options.add_argument("--window-size=1920,1080")

    if arguments:
        if type(arguments) != list:
            msg = "[错误][方法]:" + func_name() + \
                " |传入get_driver的arguments参数需要是一个list"
            logger.info(msg)
            return False, msg, ""

        for argument in arguments:
            if not argument.startswith("--"):
                argument = "--" + argument
            options.add_argument(argument)

    print("use_proxy", use_proxy)
    print("shared_obj.use_proxy", shared_obj.use_proxy)
    print("shared_obj.proxy", shared_obj.proxy)
    if use_proxy == True or (use_proxy == "use_config" and shared_obj.use_proxy):
        options.add_argument('--proxy-server=%s' % shared_obj.proxy)

    options.add_experimental_option('prefs', default_prefs)
    options.add_experimental_option(
        "excludeSwitches", ['enable-automation', 'enable-logging'])

    options.add_argument("--disable-blink-features")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option('useAutomationExtension', False)
    driver = webdriver.Chrome(chromedriver_bin_path, chrome_options=options)
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": """
        Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined
        })
    """
    })
    # 上面这些行都是为了掩藏selenium的痕迹，防止反爬虫的
    # 脚本里融入了不少在家用的方法和配置，和公司内网的关系不大，但功能强点没坏处

    if max_window_flag:
        driver.maximize_window()

    # 是否登录login.huawei.com
    # 有三种状态：use_huawei_login是在具体任务定义中的配置，优先级高。True就是要华为login；False就不要；
    # 不填才会去看全局的配置。
    if use_huawei_login_chrome == True or (use_huawei_login_chrome == "use_config" and shared_obj.use_huawei_login_chrome):
        r, msg, driver = login_huawei_com_webdriver(driver)
        if not r:
            return r, msg, ""

    return True, 'ok', driver


def parse_selector(sel_string):
    # 解析selector字符串
    # 默认的是css selector
    # [id]开头的是By.ID  [xpath]开头的是By.XPATH
    sel_type = By.CSS_SELECTOR
    if sel_string.startswith('[xpath]'):
        sel_type = By.XPATH
        sel_string = sel_string.replace("[xpath]", "", 1)
    elif sel_string.startswith('[id]'):
        sel_type = By.ID
        sel_string = sel_string.replace('[id]', '', 1)
    return sel_type, sel_string


def func_name():
    # 返回调用本方法的方法名
    return inspect.currentframe().f_back.f_code.co_name


def var_name(var):
    # 返回变量的名
    callers_local_vars = inspect.currentframe().f_back.f_locals.items()
    return [var_name for var_name, var_val in callers_local_vars if var_val is var]


def wait_ele(driver, sel_string, wait_interv=5):
    # 等匹配的第一个元素
    sel_type, sel_string = parse_selector(sel_string)
    base_info = "[错误][方法]:"+func_name()+" |[" + str(sel_type) + \
        "]:" + sel_string

    try:
        ele = WebDriverWait(driver, wait_interv).until(
            EC.presence_of_element_located((sel_type, sel_string)))
        return True, 'ok', ele
    except Exception as ex:
        msg = except_msg(ex, base_info)
        logger.error(msg)
        return False, msg, ''


def except_msg(ex, base_info):
    # 生成异常消息
    exception_template = "出现exception类型：{0} 参数信息：\n{1!r}"
    msg = exception_template.format(type(ex).__name__, ex.args)
    msg = base_info + "|" + msg
    return msg


def get_n_layer_parent_ele(ele, n):
    # 获得几层向上的元素, 向上n层
    rel_sel_string = "." + "/.." * n
    r, msg, parent_ele = find_rel_ele(ele, rel_sel_string)
    return r, msg, parent_ele


def get_grand_parent_ele(ele):
    # 获取祖父元素， 向上两级   ./../..
    rel_sel_string = "[xpath]./../.."
    r, msg, parent_ele = find_rel_ele(ele, rel_sel_string)
    return r, msg, parent_ele


def get_parent_ele(ele):
    # 获取父元素 ./..， 向上一级
    rel_sel_string = "[xpath]./.."
    r, msg, parent_ele = find_rel_ele(ele, rel_sel_string)
    return r, msg, parent_ele


def find_rel_ele(ele, rel_sel_string):
    # 根据传入的ele和相对路径，找到指定元素
    # 相对元素其实只支持xpath
    sel_type, sel_string = parse_selector(rel_sel_string)
    base_info = "[错误][方法]:"+func_name()+" |[" + str(sel_type) + \
        "]:" + sel_string
    try:
        rel_ele = ele.find_element(By.XPATH, sel_string)
        return True, "ok", rel_ele
    except Exception as ex:
        msg = except_msg(ex, base_info)
        logger.error(msg)
        return False, msg, ''


def find_rel_eles(ele, rel_sel_string):
    # 根据传入的ele和相对路径，找到指定元素(多个)
    # 相对元素只支持xpath
    sel_type, sel_string = parse_selector(rel_sel_string)
    base_info = "[错误][方法]:"+func_name()+" |[" + str(sel_type) + \
        "]:" + sel_string
    try:
        rel_eles = ele.find_elements(By.XPATH, sel_string)
        return True, "ok", rel_eles
    except Exception as ex:
        msg = except_msg(ex, base_info)
        logger.error(msg)
        return False, msg, ''


def wait_eles(driver, sel_string, wait_interv=5):
    # 等多个元素，为啥独立一个方法，我估计这个慢，下次可以比一下
    sel_type, sel_string = parse_selector(sel_string)
    base_info = "[错误][方法]:"+func_name()+" |[" + str(sel_type) + \
        "]:" + sel_string

    try:
        eles = WebDriverWait(driver, wait_interv).until(
            EC.presence_of_all_elements_located((sel_type, sel_string)))
        return True, 'ok', eles
    except Exception as ex:
        msg = except_msg(ex, base_info)
        logger.error(msg)
        return False, msg, []


def wait_clickable_ele(driver, sel_string):
    # 等匹配的单个可点击元素
    sel_type, sel_string = parse_selector(sel_string)
    base_info = "[错误][方法]:"+func_name()+"[" + str(sel_type) + "]:" + sel_string

    try:
        ele = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((sel_type, sel_string)))
        return True, 'ok', ele
    except Exception as ex:
        msg = except_msg(ex, base_info)
        logger.error(msg)
        return False, msg, ''


def do_pre_actions(driver, pre_actions):
    # 预操作逻辑处理
    for pre_action_define in pre_actions:
        action_name = pre_action_define.get('name', '')


def find_ele_then_sendkey(driver, sel_string, key_value, timeout=5, visible=True, clear=False):
    # visible 是否要求可见，默认要求可见
    sel_type, sel_string = parse_selector(sel_string)
    base_info = "[错误][方法]:"+func_name()+" |[" + str(sel_type) + \
        "]:" + sel_string

    try:
        if visible: # 如果要等到显性的元素
            ele = WebDriverWait(driver, timeout).until(
                EC.visibility_of_element_located((sel_type, sel_string)))
        else:
            ele = WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located((sel_type, sel_string)))

        if clear: # 如果有这个标记就先清空，默认不清空
            ele.clear()

        ele.send_keys(key_value)
        logger.info(base_info.replace("[错误]", "[完成输入]"))
        return True, 'ok'

    except Exception as ex:
        msg = except_msg(ex, base_info)
        logger.error(msg)
        return False, msg


def find_ele_then_click(driver, sel_string, timeout=5):
    sel_type, sel_string = parse_selector(sel_string)
    base_info = "[错误][方法]:"+func_name()+"|[" + str(sel_type) + \
        "]:" + sel_string

    try:
        ele = WebDriverWait(driver, timeout).until(
            EC.element_to_be_clickable((sel_type, sel_string)))
        # ele.click()
        ele.send_keys("\n")
        logger.info(base_info.replace("[错误]", "[完成点击]"))
        return True, 'ok'

    except Exception as ex:
        msg = except_msg(ex, base_info)
        logger.error(msg)
        return False, msg


def send_key_to_driver_globe_n(driver, n, key=Keys.TAB):
    # 有的时候可以用TAB键去定位聚焦的元素
    for _ in range(n):
        send_key_to_driver_globe(driver, key)


def send_key_to_driver_globe(driver, key=Keys.ESCAPE):
    # 对driver全局按一个按键
    # 入参是Keys.ESCAPE 这种
    webdriver.ActionChains(driver).send_keys(key).perform()


def get_matched_define(map_define, url):
    # 从map中找到匹配url的定义
    matched_define = {}
    # for define in map_define:
    for define_id in map_define:
        define = map_define[define_id]
        ptn = define.get('regex', "")
        if not ptn:
            msg = "[错误][方法]:" + func_name() + " |regex字段为空。"
            logger.error(msg)
            return False, msg, ""

        if not re.findall(ptn, rm_protocol_pre(url)):
            continue
        else:
            matched_define = define
            # 给它里面塞入一个"define_id"的字段，便于后面缓存可以用
            matched_define['define_id'] = define_id
            break

    return True, 'ok', matched_define


def rm_protocol_pre(url):
    # 去掉https 和http前缀
    return url.replace("http://", '').replace("https://", "")


def get_downloader_map():
    # 获取下载器定义文件内容
    # 会合并common和custom中的定义，冲突的以custom的为准
    _, _, jData = load_json_file(common_downloader_map_path)
    defines = jData.get("defines", {})

    _, _, jData2 = load_json_file(custom_downloader_map_path)
    defines_2 = jData2.get("defines", {})

    return True, 'ok', {**defines, **defines_2}


def get_unfolder_map():
    # 获取展开器定义文件内容
    # 会合并common和custom中的定义，冲突的以custom的为准
    _, _, jData = load_json_file(common_unfolder_map_path)
    defines = jData.get("defines", {})

    _, _, jData2 = load_json_file(custom_unfolder_map_path)
    defines_2 = jData2.get("defines", {})

    # 直接加，让defines_2的排在后面，可以覆盖common里面相同id的
    return True, 'ok', {**defines, **defines_2}


def load_unfold_cache(matched_define, start_url):
    # 尝试加载 unfold的缓存，True，就不继续unfold了，False直接忽略就ok
    define_id = matched_define.get("define_id", "")  # 这个肯定会有，不用再判断了。

    r, msg, cache_data = load_json_file(
        jj(cache_unfolder_dir, define_id+".json"), out_type="dict")
    if r and cache_data:
        all_link_list = cache_data.get("data", [])
        last_time_stamp = cache_data.get("time_stamp", 0)  # 找不到就是0，肯定超时
        last_define_str = cache_data.get("define_str", "")  # 上次的define
        last_start_url = cache_data.get("start_url", "")  # 上次的start_url

        # 这个是一个开关
        cache_unfold_last_days = matched_define.get(
            "cache_unfold_last_days", shared_obj.cache_unfold_last_days)
        this_define_str = json.dumps(matched_define)
        this_time_stamp = now_time_stamp()

        # 任务定义相同，时间不超期，起始url相同的情况，才会直接拿缓存的数据
        # 去掉无关紧要的字段
        skip_keys = ['cache_unfold_last_days']

        get_cache = False
        if unfold_defines_are_equal(this_define_str, last_define_str, skip_keys) and start_url == last_start_url:
            if cache_unfold_last_days == -1:
                get_cache = True
                info_str = "本unfold配置为不过期。"
            elif cache_unfold_last_days > 0 and this_time_stamp - last_time_stamp < cache_unfold_last_days*24*3600:
                get_cache = True
                info_str = "过期时间为：" + str(cache_unfold_last_days) + "天， 尚未过期。"

            if get_cache:
                msg = "[从缓存中得到展开数据]:" + start_url + " | " + \
                    info_str + " \n[获取目标链接个数]：" + str(len(all_link_list))
                logger.info(msg)
                return True, msg, all_link_list

    return False, '', []


def unfold_defines_are_equal(json_str_1, json_str_2, skip_keys):
    # 判断两个json是相同的
    data1 = json.loads(json_str_1)
    data2 = json.loads(json_str_2)
    for key in skip_keys:
        if key in data1:
            del data1[key]
        if key in data2:
            del data2[key]

    d1_keys = set(data1.keys())
    d2_keys = set(data2.keys())
    if d1_keys - d2_keys:  # 说明key不一样，返回False
        return False

    for key in d1_keys:
        if data1[key] != data2[key]:
            return False
    return True


def save_unfold_cache(matched_define, data, start_url):
    # 将data封装一层，加时间戳，加define定义字段,加start_url
    define_id = matched_define.get("define_id", "")  # 这个肯定会有，不用再判断了。

    out = {}
    out['data'] = data
    out['time_stamp'] = now_time_stamp()
    out['define_str'] = json.dumps(matched_define)  # 对任务的定义
    out['start_url'] = start_url

    save_json_file(jj(cache_unfolder_dir, define_id+".json"), out)


def save_json_file(file_path, data):
    # 写json文件
    with open(file_path, 'w', encoding='utf8') as f:
        f.write(json.dumps(data, indent=4, ensure_ascii=False))


def load_json_file(file_path, out_type="dict"):
    # 用于获取站点定义的json，这个json的最外层原来只是个list，但这样不能存其他元数据，比如更新事件等，，所以最外层再套一层dict
    if out_type == "dict":  # 最外层的类型，加这个参数就灵活点
        jData = {}
    elif out_type == "list":
        jData = []

    if not os.path.isfile(file_path):
        msg = "[警告][方法]:" + func_name() + " |文件" + file_path + "不存在。|"
        logger.info(msg)
        return False, msg, jData

    with open(file_path, 'r', encoding='utf8') as f:
        con = f.read()
        try:
            jData = json.loads(con)
            return True, 'ok', jData
        except Exception as ex:
            base_info = "[错误][方法]:"+func_name()+" |文件" + \
                file_path + "json文件格式不正确 |"
            msg = except_msg(ex, base_info)
            logger.error(msg)
            return False, msg, jData


def get_text_excluding_children(driver, element):
    # 获取元素文本，不带子元素的。element.text就能拿到所有的文本
    return driver.execute_script("""
    var parent = arguments[0];
    var child = parent.firstChild;
    var ret = "";
    while(child){
        if (child.nodeType === Node.TEXT_NODE)
            ret += child.textContent;
        child = child.nextSibling;
    }
    return ret;
    """, element)


def get_previous_sibling_text(driver, element):
    # 获取本元素上一个元素的text node
    return driver.execute_script("""
    return arguments[0].previousSibling.textContent;
    """, element)


def scroll_down(driver):
    # 浏览器滚到底部
    # driver.execute_script("""window.scrollTo(0,document.body.scrollHeight)""")
    send_key_to_driver_globe(driver, Keys.END)
    time.sleep(0.5)


def check_remove_element(driver, css_sel, wait_interv=5):
    # 等这个元素出现后，再删掉这个元素
    r, _, _ = wait_ele(driver, css_sel, wait_interv)
    if r:
        remove_element(driver, css_sel)


def remove_element(driver, css_sel):
    # 从driver中删掉指定的css selector选中的元素
    driver.execute_script("""var l = document.querySelector("[[[r]]]");
    l.parentNode.removeChild(l);
    """.replace('[[[r]]]', css_sel))
    return driver


def check_abs_url(current_url, check_url):
    # 检查参数check_url是否时绝对url路径，current_url是当前浏览器的url
    # 返回绝对url
    host, _ = get_host_from_url(current_url)
    if host not in check_url:
        check_url = urljoin(current_url, check_url)
    return check_url


def get_host_from_url(url):
    # 从url中拿主机名
    parsed_uri = urlparse(url)
    full_host = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)
    return full_host, parsed_uri.scheme


def is_chinese_str(string):
    # 看字符串是否中文
    ptn = r"[\u4e00-\u9fa5]+"
    return re.findall(ptn, string)


def is_chinese(char):
    # 看看字符是不是中文
    if char >= u'\u4e00' and char <= u'\u9fa5':
        return True
    else:
        return False


def convert_to_simple_chinese(ori_str):
    return zhconv.convert(ori_str, "zh-cn")


def windows_name_filter(ori):
    # 用于文件名、 目录名
    # 把不符合windows文件名规范的字符替换成下划线
    # forbid_char_list = ["\\", "/", "\"", ":", "*", "?", "<", ">", "|"]
    ptn = r"[\/\\\:\*\?\"\<\>\|]"
    return re.sub(ptn, "_", ori).strip(".")


def windows_path_filter(ori):
    # 用于完整路径
    # 把不符合windows文件名规范的字符替换成下划线
    # forbid_char_list = ["\\", "/", "\"", ":", "*", "?", "<", ">", "|"]
    ptn = r"[\*\?\"\<\>\|]"
    return re.sub(ptn, "_", ori).strip(".")


def gen_escaped_user_pwd_str(user, pwd):
    # 生成proxy前面的用户、密码的前缀
    return user + ":" + escape_character_in_str(pwd) + "@"


def escape_character_in_str(ori):
    # 将密码中的一些特殊字符完成转义，便于使用proxy的auth
    # 用户名里面半没有特殊字符。下面虽然是个dict，但python3.6以后dict也是有序的，顺序替换即可。
    key_map = {
        "%": "%25",
        "#": "%23",
        "@": "%40",
        ":": "%3a",
        ";": "%3b",
        "?": "%3f",
        "$": "%24",
        "!": "%21",
        "/": "%2f",
        "'": "%27",
        "\"": "%22"
    }
    for key in key_map:
        ori = ori.replace(key, key_map[key])
    return ori


def set_socket_timout(timeout="use_config"):
    if timeout == "use_config":
        timeout = shared_obj.socket_timeout
    socket.setdefaulttimeout(timeout)


def rreplace(all_str, fro, to, times):
    # 从右侧替换
    return all_str[::-1].replace(fro[::-1], to[::-1], times)[::-1]


def ret_random_name(n, use_fix=True):
    name = ""
    if use_fix:
        for _ in range(n):
            name += str(random.randint(0, 9))
    else:
        for _ in range(random.randint(0, 9)):
            name += str(random.randint(0, 9))
    return name


def ret_random_id():
    # 用这个来生成定义的id吧，随机、唯一（几乎）的id
    return "_".join([ret_random_name(1), ret_random_name(8), ret_random_name(8), ret_random_name(8)])


def now_time_stamp():
    # 返回当前的utc时间,int
    return datetime.utcnow().timestamp()


def now_date_2_str():
    # 返回当前日期、时间的字符串。
    # 返回两个时间，前一个到秒，后一个到微秒
    s = str(datetime.now()).replace(":", "").replace("-", "").replace(" ", "")
    return s.split(".")[0], s.replace(".", "")


def walk_all_dir(dir, exclude_ptn_list=None, allow_ext_list=None):
    # 递归遍历目录，返回符合条件的文件路径list
    # allow_ext_list中罗列后缀名小写即可， 下面自动处理大小写的情况。
    if exclude_ptn_list is None:
        exclude_ptn_list = []
    if allow_ext_list is None:
        allow_ext_list = []

    file_list = []
    for dir_path, _, files in os.walk(dir):
        for f in files:
            file_path = jj(dir_path, f)
            if allow_ext_list and os.path.splitext(file_path)[1].lower() not in allow_ext_list:
                continue

        if exclude_ptn_list:
            not_exclude = True
            for e in exclude_ptn_list:
                if e in file_path:
                    not_exclude = False
                    break
            if not_exclude:
                file_list.append(file_path)
        else:
            file_list.append(file_path)
    return file_list


def retSubFolderPathList(parent_folder):
    # 返回指定目录中所有folder的全path列表
    return [jj(parent_folder, d) for d in os.listdir(parent_folder) if os.path.isdir(jj(parent_folder, d))]


def retSubFolderList(parent_folder):
    # 返回指定目录中目录名（非全路径）列表
    return [d for d in os.listdir(parent_folder) if os.path.isdir(jj(parent_folder, d))]


def ret_md5(fName):
    if not os.path.isfile(fName):
        return False, '[错误]文件不存在：'+ fName, ''

    hash_md5 = hashlib.md5()
    with open(fName, 'rb') as f:
        for chunk in iter(lambda: f.read(4096), eval("b''")):
            hash_md5.update(chunk)
    return True, 'ok', hash_md5.hexdigest()



def login_huawei_com_webdriver(driver, jump_url=""):
    # 返回一个已经登陆成功的driver
    # jump_url 是用于跳转的url
    r, msg, uid, pwd = get_account()
    if not r:
        return r, msg, ""

    if not jump_url:
        jump_url = "https://login.huawei.com/login/"
    driver.get(jump_url)

    # 用户名
    r, msg = find_ele_then_sendkey(driver, '[id]uid', uid)
    if not r:
        return r, msg, ""

    # 密码
    r, msg = find_ele_then_sendkey(driver, '[id]password', pwd + "\n")
    if not r:
        return r, msg, ""

    return True, 'ok', driver


def is_connected(hostname):
    # 测试是否能到达主机
  try:
    host = socket.gethostbyname(hostname)
    s = socket.create_connection((host, 80), 2)
    s.close()
    return True
  except:
     pass

  logger.info("[错误]网络无连接，尝试连接url失败:" + hostname)
  return False


def test_network():
    # 测试网络连接
    return is_connected(default_conf['network_test_url'])


def get_account(file_name=password_conf_file):
    # 获取预置的用户名、密码, 这个账户密码主要是w3密码，但是目前用公司的AD服务来鉴权，用的是域账户密码
    if not os.path.isfile(password_conf_file):
        msg = "[错误][方法]:" + func_name() + " |用户名配置文件不存在：" + password_conf_file
        logger.info(msg)
        return False, msg, "", ""

    with open(file_name, 'r', encoding='utf8') as f:
        lines = f.readlines()
        account = ''
        password = ''
        if len(lines) > 1:
            account = lines[0].strip().split("=")[1]
            password = lines[1].strip().split("=")[1]

        return True, 'ok', account, password


def check_integrity():
    # 检查依赖完整性
    # 这里不用这么一个个文件的罗列，再一一检查，打包后执行dirty_work的时候，打包成安装文件前，执行一次全目录遍历。
    # 把所有的文件罗列一个list，检查的时候读这个list，然后多线程去查，这样代码也很清晰，维护又简单。
    # 不过这种模式在exe模式下运行，py模式下不会走这个逻辑
    pass


def start_check():
    # 启动时完整性的检查
    # 检查3rd中文件的存在
    r, msg = check_chrome_and_driver()
    if not r:
        return r,msg
    
    return True, 'ok'


def start_mitmproxy():
    # 启动mitmproxy
    pass


def kill_mitmproxy():
    # 关闭mitmproxy进程
    pass


def init():
    # 模块被import的时候，完成初始化。 关键的配置都在配置文件中，在不同模块间重复import，全局变量模块shared_obj不会受到影响。
    r = test_network()
    if not r:
        return r, "[错误]网络连接失败"

    default_conf_to_sharedobj()
    read_sys_conf_to_sharedobj()
    r,msg = start_check()
    if not r:
        return r,msg

    return True,'ok'
# 不要一import就掉这个，这个文件主要是可重用的库文件
# init()
